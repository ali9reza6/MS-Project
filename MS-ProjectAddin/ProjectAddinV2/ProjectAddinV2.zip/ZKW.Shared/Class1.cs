﻿using System;

namespace ZKW.Shared
{
    public class Class1
    {
    }
}
